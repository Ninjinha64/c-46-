//variáveis necessárias
var mario, marioImg;
var nuvens;


//carregamento de imagens
function preload() {
    marioImg = loadImage("./assets/mario1.png");


}

function setup() {
    //canvas
    createCanvas(windowWidth, windowHeight);

    //sprite do mário
    mario = createSprite(50, height - 40, 20, 50);

}

function draw() {
    //cor de fundo
    background("purple");


    //desenhando sprites
    drawSprites();
}